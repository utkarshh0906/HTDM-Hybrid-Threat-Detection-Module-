# 🛡️ Hybrid Threat Detection — Chrome Extension

Analyze any selected text on any webpage for:
- 📰 **Fake News** probability
- 😤 **Cyberbullying** risk  
- 🎭 **Deepfake** risk
- 🤖 **AI-Generated** text probability

A frosted-glass translucent panel floats near your selection with animated score bars.

---

## 📁 File Structure

```
hybrid-threat-extension/
├── manifest.json       ← Chrome extension config
├── background.js       ← Service worker (API proxy + context menu)
├── content.js          ← Injected into every page (panel UI logic)
├── content.css         ← Frosted-glass panel styles
├── popup.html          ← Toolbar popup (status + instructions)
├── popup.js            ← Popup health-check logic
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## 🚀 Setup (2 steps)

### Step 1 — Start the backend
```bash
# In the folder containing app.py and your .pkl models:
uvicorn app:app --reload
```

### Step 2 — Load the extension in Chrome
1. Open Chrome → go to `chrome://extensions`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select this `hybrid-threat-extension/` folder
5. The 🛡️ icon appears in your Chrome toolbar

---

## 🎯 How to use

**Method A — Tooltip (fastest):**
1. Select any text on any webpage (≥10 characters)
2. A small pill appears: **🛡️ Analyze threat** — click it
3. The frosted-glass panel appears with scores

**Method B — Right-click:**
1. Select text
2. Right-click → **"🛡️ Analyze with Threat Detector"**

**Method C — Check status:**
- Click the 🛡️ toolbar icon to see if the backend is online and which models are loaded

---

## 💡 Panel features

| Feature | Detail |
|---------|--------|
| **Draggable** | Grab the header bar and drag anywhere |
| **Pin** | Click 📌 Pin to keep it open while you browse |
| **Escape** | Press `Esc` to dismiss |
| **Auto-dismiss** | Clicking elsewhere closes the panel (unless pinned) |
| **Animated bars** | Scores animate from 0 to the actual value |

---

## 🔧 Troubleshooting

| Problem | Fix |
|---------|-----|
| Panel shows "Cannot reach backend" | Run `uvicorn app:app --reload` first |
| Extension not loading | Make sure Developer Mode is ON in `chrome://extensions` |
| Models show "Not found" | Place `.pkl` files next to `app.py` and restart uvicorn |
| Panel doesn't appear | Select at least 10 characters of text |
